export function genPassword(userId){
	return userId;
}