export const languagesNaming = [
  {
    "en": "english",
    "fr": "anglais",
  },
  {
    "en": "french",
    "fr": "français",
  },
  {
    "en": "spanish",
    "fr": "espagnol",
  },
  {
    "en": "arabic",
    "fr": "arabe",
  },
  {
    "en": "estonian",
    "fr": "estonien",
  },
  {
    "en": "japanese",
    "fr": "japonais",
  },
  {
    "en": "hebrew",
    "fr": "hébreu",
  },
  {
    "en": "swedish",
    "fr": "suédois",
  },
  {
    "en": "finnish",
    "fr": "finnois",
  },
  {
    "en": "german",
    "fr": "allemand",
  },
];
